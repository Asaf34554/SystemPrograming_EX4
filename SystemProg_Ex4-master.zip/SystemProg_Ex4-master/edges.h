#ifndef EDGE_
#define EDGE_
#include "graph.h"

pedge create_edge();
char create_edges(pnode vertex, pnode *head);
void del_edges(pnode vertex);
void del_edge(pnode ver,pnode endp);
 
#endif